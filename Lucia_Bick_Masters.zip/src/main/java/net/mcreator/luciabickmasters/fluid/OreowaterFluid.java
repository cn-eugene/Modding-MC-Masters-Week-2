
package net.mcreator.luciabickmasters.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.luciabickmasters.init.LuciaBickMastersModItems;
import net.mcreator.luciabickmasters.init.LuciaBickMastersModFluids;
import net.mcreator.luciabickmasters.init.LuciaBickMastersModFluidTypes;
import net.mcreator.luciabickmasters.init.LuciaBickMastersModBlocks;

public abstract class OreowaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> LuciaBickMastersModFluidTypes.OREOWATER_TYPE.get(), () -> LuciaBickMastersModFluids.OREOWATER.get(),
			() -> LuciaBickMastersModFluids.FLOWING_OREOWATER.get()).explosionResistance(100f).bucket(() -> LuciaBickMastersModItems.OREOWATER_BUCKET.get()).block(() -> (LiquidBlock) LuciaBickMastersModBlocks.OREOWATER.get());

	private OreowaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends OreowaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends OreowaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
