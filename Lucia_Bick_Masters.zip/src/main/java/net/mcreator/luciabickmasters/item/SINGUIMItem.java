
package net.mcreator.luciabickmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SINGUIMItem extends Item {
	public SINGUIMItem() {
		super(new Item.Properties().stacksTo(62).rarity(Rarity.COMMON));
	}
}
