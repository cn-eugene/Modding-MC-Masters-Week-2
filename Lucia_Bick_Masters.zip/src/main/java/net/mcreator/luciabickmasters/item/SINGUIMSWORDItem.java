
package net.mcreator.luciabickmasters.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.luciabickmasters.init.LuciaBickMastersModItems;

public class SINGUIMSWORDItem extends SwordItem {
	public SINGUIMSWORDItem() {
		super(new Tier() {
			public int getUses() {
				return 178;
			}

			public float getSpeed() {
				return 1f;
			}

			public float getAttackDamageBonus() {
				return 3f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 27;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(LuciaBickMastersModItems.SINGUIMINGET.get()));
			}
		}, 3, -2.3f, new Item.Properties());
	}
}
