
package net.mcreator.luciabickmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SINGUIMINGETItem extends Item {
	public SINGUIMINGETItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
