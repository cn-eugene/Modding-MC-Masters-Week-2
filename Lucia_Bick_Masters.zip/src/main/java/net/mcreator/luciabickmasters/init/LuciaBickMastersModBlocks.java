
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luciabickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.luciabickmasters.block.YaroreoBlock;
import net.mcreator.luciabickmasters.block.SINGUIMBLOCKBlock;
import net.mcreator.luciabickmasters.block.OreowoodBlock;
import net.mcreator.luciabickmasters.block.OreowawaBlock;
import net.mcreator.luciabickmasters.block.OreowaterBlock;
import net.mcreator.luciabickmasters.block.OreoleafBlock;
import net.mcreator.luciabickmasters.block.OreodirtBlock;
import net.mcreator.luciabickmasters.block.OreoBlock;
import net.mcreator.luciabickmasters.block.NuckblockBlock;
import net.mcreator.luciabickmasters.block.NamodiBlock;
import net.mcreator.luciabickmasters.block.BlookBlock;
import net.mcreator.luciabickmasters.block.BLOODBlock;
import net.mcreator.luciabickmasters.LuciaBickMastersMod;

public class LuciaBickMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LuciaBickMastersMod.MODID);
	public static final RegistryObject<Block> SINGUIMBLOCK = REGISTRY.register("singuimblock", () -> new SINGUIMBLOCKBlock());
	public static final RegistryObject<Block> NUCKBLOCK = REGISTRY.register("nuckblock", () -> new NuckblockBlock());
	public static final RegistryObject<Block> BLOOD = REGISTRY.register("blood", () -> new BLOODBlock());
	public static final RegistryObject<Block> BLOOK = REGISTRY.register("blook", () -> new BlookBlock());
	public static final RegistryObject<Block> NAMODI = REGISTRY.register("namodi", () -> new NamodiBlock());
	public static final RegistryObject<Block> OREO = REGISTRY.register("oreo", () -> new OreoBlock());
	public static final RegistryObject<Block> YAROREO = REGISTRY.register("yaroreo", () -> new YaroreoBlock());
	public static final RegistryObject<Block> OREOWOOD = REGISTRY.register("oreowood", () -> new OreowoodBlock());
	public static final RegistryObject<Block> OREODIRT = REGISTRY.register("oreodirt", () -> new OreodirtBlock());
	public static final RegistryObject<Block> OREOWAWA = REGISTRY.register("oreowawa", () -> new OreowawaBlock());
	public static final RegistryObject<Block> OREOLEAF = REGISTRY.register("oreoleaf", () -> new OreoleafBlock());
	public static final RegistryObject<Block> OREOWATER = REGISTRY.register("oreowater", () -> new OreowaterBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
