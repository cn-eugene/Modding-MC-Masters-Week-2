
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luciabickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.luciabickmasters.enchantment.DiesoflightingEnchantment;
import net.mcreator.luciabickmasters.LuciaBickMastersMod;

public class LuciaBickMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, LuciaBickMastersMod.MODID);
	public static final RegistryObject<Enchantment> DIESOFLIGHTING = REGISTRY.register("diesoflighting", () -> new DiesoflightingEnchantment());
}
