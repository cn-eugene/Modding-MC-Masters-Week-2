
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luciabickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.luciabickmasters.entity.ShadowCatEntity;
import net.mcreator.luciabickmasters.entity.SAMEntity;
import net.mcreator.luciabickmasters.entity.JEROLDEntity;
import net.mcreator.luciabickmasters.LuciaBickMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LuciaBickMastersModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, LuciaBickMastersMod.MODID);
	public static final RegistryObject<EntityType<JEROLDEntity>> JEROLD = register("jerold",
			EntityType.Builder.<JEROLDEntity>of(JEROLDEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(66).setUpdateInterval(3).setCustomClientFactory(JEROLDEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SAMEntity>> SAM = register("sam",
			EntityType.Builder.<SAMEntity>of(SAMEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SAMEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ShadowCatEntity>> SHADOW_CAT = register("shadow_cat", EntityType.Builder.<ShadowCatEntity>of(ShadowCatEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(ShadowCatEntity::new).fireImmune().sized(0.6f, 0.7f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			JEROLDEntity.init();
			SAMEntity.init();
			ShadowCatEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(JEROLD.get(), JEROLDEntity.createAttributes().build());
		event.put(SAM.get(), SAMEntity.createAttributes().build());
		event.put(SHADOW_CAT.get(), ShadowCatEntity.createAttributes().build());
	}
}
