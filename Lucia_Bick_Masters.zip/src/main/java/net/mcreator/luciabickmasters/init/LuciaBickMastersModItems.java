
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luciabickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.luciabickmasters.item.SeepItem;
import net.mcreator.luciabickmasters.item.SINGUIMSWORDItem;
import net.mcreator.luciabickmasters.item.SINGUIMItem;
import net.mcreator.luciabickmasters.item.SINGUIMINGETItem;
import net.mcreator.luciabickmasters.item.OreowaterItem;
import net.mcreator.luciabickmasters.item.FgfgfgItem;
import net.mcreator.luciabickmasters.item.BLOODItem;
import net.mcreator.luciabickmasters.LuciaBickMastersMod;

public class LuciaBickMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LuciaBickMastersMod.MODID);
	public static final RegistryObject<Item> SINGUIM = REGISTRY.register("singuim", () -> new SINGUIMItem());
	public static final RegistryObject<Item> SINGUIMBLOCK = block(LuciaBickMastersModBlocks.SINGUIMBLOCK);
	public static final RegistryObject<Item> SINGUIMINGET = REGISTRY.register("singuiminget", () -> new SINGUIMINGETItem());
	public static final RegistryObject<Item> SINGUIMSWORD = REGISTRY.register("singuimsword", () -> new SINGUIMSWORDItem());
	public static final RegistryObject<Item> NUCKBLOCK = block(LuciaBickMastersModBlocks.NUCKBLOCK);
	public static final RegistryObject<Item> FGFGFG_HELMET = REGISTRY.register("fgfgfg_helmet", () -> new FgfgfgItem.Helmet());
	public static final RegistryObject<Item> FGFGFG_CHESTPLATE = REGISTRY.register("fgfgfg_chestplate", () -> new FgfgfgItem.Chestplate());
	public static final RegistryObject<Item> FGFGFG_LEGGINGS = REGISTRY.register("fgfgfg_leggings", () -> new FgfgfgItem.Leggings());
	public static final RegistryObject<Item> FGFGFG_BOOTS = REGISTRY.register("fgfgfg_boots", () -> new FgfgfgItem.Boots());
	public static final RegistryObject<Item> BLOOD_BUCKET = REGISTRY.register("blood_bucket", () -> new BLOODItem());
	public static final RegistryObject<Item> BLOOK = block(LuciaBickMastersModBlocks.BLOOK);
	public static final RegistryObject<Item> JEROLD_SPAWN_EGG = REGISTRY.register("jerold_spawn_egg", () -> new ForgeSpawnEggItem(LuciaBickMastersModEntities.JEROLD, -6710887, -205, new Item.Properties()));
	public static final RegistryObject<Item> SAM_SPAWN_EGG = REGISTRY.register("sam_spawn_egg", () -> new ForgeSpawnEggItem(LuciaBickMastersModEntities.SAM, -256, -65485, new Item.Properties()));
	public static final RegistryObject<Item> SEEP = REGISTRY.register("seep", () -> new SeepItem());
	public static final RegistryObject<Item> NAMODI = block(LuciaBickMastersModBlocks.NAMODI);
	public static final RegistryObject<Item> OREO = block(LuciaBickMastersModBlocks.OREO);
	public static final RegistryObject<Item> YAROREO = block(LuciaBickMastersModBlocks.YAROREO);
	public static final RegistryObject<Item> OREOWOOD = block(LuciaBickMastersModBlocks.OREOWOOD);
	public static final RegistryObject<Item> OREODIRT = block(LuciaBickMastersModBlocks.OREODIRT);
	public static final RegistryObject<Item> OREOWAWA = block(LuciaBickMastersModBlocks.OREOWAWA);
	public static final RegistryObject<Item> OREOLEAF = block(LuciaBickMastersModBlocks.OREOLEAF);
	public static final RegistryObject<Item> OREOWATER_BUCKET = REGISTRY.register("oreowater_bucket", () -> new OreowaterItem());
	public static final RegistryObject<Item> SHADOW_CAT_SPAWN_EGG = REGISTRY.register("shadow_cat_spawn_egg", () -> new ForgeSpawnEggItem(LuciaBickMastersModEntities.SHADOW_CAT, -16777216, -3407872, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
