
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luciabickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.luciabickmasters.LuciaBickMastersMod;

public class LuciaBickMastersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, LuciaBickMastersMod.MODID);
	public static final RegistryObject<Potion> RAIN_POTION = REGISTRY.register("rain_potion", () -> new Potion(new MobEffectInstance(LuciaBickMastersModMobEffects.RAIN.get(), 3600, 0, false, true)));
}
