
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.luciabickmasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.luciabickmasters.LuciaBickMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LuciaBickMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LuciaBickMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(LuciaBickMastersModBlocks.BLOOK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(LuciaBickMastersModBlocks.NUCKBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LuciaBickMastersModItems.SINGUIMSWORD.get());
			tabData.accept(LuciaBickMastersModItems.FGFGFG_HELMET.get());
			tabData.accept(LuciaBickMastersModItems.FGFGFG_CHESTPLATE.get());
			tabData.accept(LuciaBickMastersModItems.FGFGFG_LEGGINGS.get());
			tabData.accept(LuciaBickMastersModItems.FGFGFG_BOOTS.get());
			tabData.accept(LuciaBickMastersModItems.SEEP.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LuciaBickMastersModItems.JEROLD_SPAWN_EGG.get());
			tabData.accept(LuciaBickMastersModItems.SAM_SPAWN_EGG.get());
			tabData.accept(LuciaBickMastersModItems.SHADOW_CAT_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LuciaBickMastersModItems.SINGUIM.get());
			tabData.accept(LuciaBickMastersModItems.SINGUIMINGET.get());
			tabData.accept(LuciaBickMastersModItems.BLOOD_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LuciaBickMastersModBlocks.SINGUIMBLOCK.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.NAMODI.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.OREO.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.YAROREO.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.OREOWOOD.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.OREODIRT.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.OREOWAWA.get().asItem());
			tabData.accept(LuciaBickMastersModBlocks.OREOLEAF.get().asItem());
			tabData.accept(LuciaBickMastersModItems.OREOWATER_BUCKET.get());
		}
	}
}
