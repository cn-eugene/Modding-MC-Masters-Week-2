
package net.mcreator.luciabickmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.OcelotModel;

import net.mcreator.luciabickmasters.entity.ShadowCatEntity;

public class ShadowCatRenderer extends MobRenderer<ShadowCatEntity, OcelotModel<ShadowCatEntity>> {
	public ShadowCatRenderer(EntityRendererProvider.Context context) {
		super(context, new OcelotModel(context.bakeLayer(ModelLayers.OCELOT)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ShadowCatEntity entity) {
		return new ResourceLocation("lucia_bick_masters:textures/entities/cat.png");
	}
}
