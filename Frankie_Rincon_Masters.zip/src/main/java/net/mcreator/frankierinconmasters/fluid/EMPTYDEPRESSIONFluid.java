
package net.mcreator.frankierinconmasters.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.frankierinconmasters.init.FrankieRinconMastersModItems;
import net.mcreator.frankierinconmasters.init.FrankieRinconMastersModFluids;
import net.mcreator.frankierinconmasters.init.FrankieRinconMastersModFluidTypes;
import net.mcreator.frankierinconmasters.init.FrankieRinconMastersModBlocks;

public abstract class EMPTYDEPRESSIONFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> FrankieRinconMastersModFluidTypes.EMPTYDEPRESSION_TYPE.get(), () -> FrankieRinconMastersModFluids.EMPTYDEPRESSION.get(),
			() -> FrankieRinconMastersModFluids.FLOWING_EMPTYDEPRESSION.get()).explosionResistance(100f).tickRate(10).bucket(() -> FrankieRinconMastersModItems.EMPTYDEPRESSION_BUCKET.get())
			.block(() -> (LiquidBlock) FrankieRinconMastersModBlocks.EMPTYDEPRESSION.get());

	private EMPTYDEPRESSIONFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.SMOKE;
	}

	public static class Source extends EMPTYDEPRESSIONFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends EMPTYDEPRESSIONFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
