
package net.mcreator.frankierinconmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RawsilverItem extends Item {
	public RawsilverItem() {
		super(new Item.Properties().stacksTo(64).fireResistant().rarity(Rarity.COMMON));
	}
}
