
package net.mcreator.frankierinconmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BfItem extends Item {
	public BfItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
