
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.frankierinconmasters.enchantment.MegalovaniaEnchantment;
import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

public class FrankieRinconMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, FrankieRinconMastersMod.MODID);
	public static final RegistryObject<Enchantment> MEGALOVANIA = REGISTRY.register("megalovania", () -> new MegalovaniaEnchantment());
}
