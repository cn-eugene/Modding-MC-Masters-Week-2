
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class FrankieRinconMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FrankieRinconMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(FrankieRinconMastersModBlocks.NUCLEARMISSILE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(FrankieRinconMastersModItems.EMPTYDEPRESSION_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(FrankieRinconMastersModItems.KNIFE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(FrankieRinconMastersModItems.CHARA_SPAWN_EGG.get());
			tabData.accept(FrankieRinconMastersModItems.BFCHICKEN_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(FrankieRinconMastersModItems.RAWSILVER.get());
			tabData.accept(FrankieRinconMastersModItems.SILVER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(FrankieRinconMastersModBlocks.WHITE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(FrankieRinconMastersModBlocks.SILVERORE.get().asItem());
			tabData.accept(FrankieRinconMastersModBlocks.BONESTICKS.get().asItem());
			tabData.accept(FrankieRinconMastersModBlocks.BLOODIEDSTONE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(FrankieRinconMastersModItems.DOMIAN.get());
		}
	}
}
