
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.frankierinconmasters.item.SilverItem;
import net.mcreator.frankierinconmasters.item.RawsilverItem;
import net.mcreator.frankierinconmasters.item.KnifeItem;
import net.mcreator.frankierinconmasters.item.EMPTYDEPRESSIONItem;
import net.mcreator.frankierinconmasters.item.DomianItem;
import net.mcreator.frankierinconmasters.item.BfItem;
import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

public class FrankieRinconMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FrankieRinconMastersMod.MODID);
	public static final RegistryObject<Item> RAWSILVER = REGISTRY.register("rawsilver", () -> new RawsilverItem());
	public static final RegistryObject<Item> SILVERORE = block(FrankieRinconMastersModBlocks.SILVERORE);
	public static final RegistryObject<Item> KNIFE = REGISTRY.register("knife", () -> new KnifeItem());
	public static final RegistryObject<Item> SILVER = REGISTRY.register("silver", () -> new SilverItem());
	public static final RegistryObject<Item> NUCLEARMISSILE = block(FrankieRinconMastersModBlocks.NUCLEARMISSILE);
	public static final RegistryObject<Item> BF = REGISTRY.register("bf", () -> new BfItem());
	public static final RegistryObject<Item> EMPTYDEPRESSION_BUCKET = REGISTRY.register("emptydepression_bucket", () -> new EMPTYDEPRESSIONItem());
	public static final RegistryObject<Item> CHARA_SPAWN_EGG = REGISTRY.register("chara_spawn_egg", () -> new ForgeSpawnEggItem(FrankieRinconMastersModEntities.CHARA, -16777216, -3407872, new Item.Properties()));
	public static final RegistryObject<Item> BONESTICKS = block(FrankieRinconMastersModBlocks.BONESTICKS);
	public static final RegistryObject<Item> BLOODIEDSTONE = block(FrankieRinconMastersModBlocks.BLOODIEDSTONE);
	public static final RegistryObject<Item> STONE = block(FrankieRinconMastersModBlocks.STONE);
	public static final RegistryObject<Item> WHITE = block(FrankieRinconMastersModBlocks.WHITE);
	public static final RegistryObject<Item> DOMIAN = REGISTRY.register("domian", () -> new DomianItem());
	public static final RegistryObject<Item> BFCHICKEN_SPAWN_EGG = REGISTRY.register("bfchicken_spawn_egg", () -> new ForgeSpawnEggItem(FrankieRinconMastersModEntities.BFCHICKEN, -1, -13369345, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
