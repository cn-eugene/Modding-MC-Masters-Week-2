
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

public class FrankieRinconMastersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, FrankieRinconMastersMod.MODID);
	public static final RegistryObject<Potion> EE_ESSS_SR_AIN_IN_GA_AR_OOHW_AS = REGISTRY.register("ee_esss_sr_ain_in_ga_ar_oohw_as", () -> new Potion(new MobEffectInstance(FrankieRinconMastersModMobEffects.ARROW.get(), 200, 0, false, true)));
}
