
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.frankierinconmasters.potion.ArrowMobEffect;
import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

public class FrankieRinconMastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, FrankieRinconMastersMod.MODID);
	public static final RegistryObject<MobEffect> ARROW = REGISTRY.register("arrow", () -> new ArrowMobEffect());
}
