
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.frankierinconmasters.fluid.EMPTYDEPRESSIONFluid;
import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

public class FrankieRinconMastersModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, FrankieRinconMastersMod.MODID);
	public static final RegistryObject<FlowingFluid> EMPTYDEPRESSION = REGISTRY.register("emptydepression", () -> new EMPTYDEPRESSIONFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_EMPTYDEPRESSION = REGISTRY.register("flowing_emptydepression", () -> new EMPTYDEPRESSIONFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(EMPTYDEPRESSION.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_EMPTYDEPRESSION.get(), RenderType.translucent());
		}
	}
}
