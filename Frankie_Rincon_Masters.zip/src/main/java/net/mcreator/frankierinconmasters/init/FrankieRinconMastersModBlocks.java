
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.frankierinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.frankierinconmasters.block.WhiteBlock;
import net.mcreator.frankierinconmasters.block.StoneBlock;
import net.mcreator.frankierinconmasters.block.SilveroreBlock;
import net.mcreator.frankierinconmasters.block.NUCLEARMISSILEBlock;
import net.mcreator.frankierinconmasters.block.EMPTYDEPRESSIONBlock;
import net.mcreator.frankierinconmasters.block.DomianPortalBlock;
import net.mcreator.frankierinconmasters.block.BonesticksBlock;
import net.mcreator.frankierinconmasters.block.BloodiedstoneBlock;
import net.mcreator.frankierinconmasters.FrankieRinconMastersMod;

public class FrankieRinconMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FrankieRinconMastersMod.MODID);
	public static final RegistryObject<Block> SILVERORE = REGISTRY.register("silverore", () -> new SilveroreBlock());
	public static final RegistryObject<Block> NUCLEARMISSILE = REGISTRY.register("nuclearmissile", () -> new NUCLEARMISSILEBlock());
	public static final RegistryObject<Block> EMPTYDEPRESSION = REGISTRY.register("emptydepression", () -> new EMPTYDEPRESSIONBlock());
	public static final RegistryObject<Block> BONESTICKS = REGISTRY.register("bonesticks", () -> new BonesticksBlock());
	public static final RegistryObject<Block> BLOODIEDSTONE = REGISTRY.register("bloodiedstone", () -> new BloodiedstoneBlock());
	public static final RegistryObject<Block> STONE = REGISTRY.register("stone", () -> new StoneBlock());
	public static final RegistryObject<Block> WHITE = REGISTRY.register("white", () -> new WhiteBlock());
	public static final RegistryObject<Block> DOMIAN_PORTAL = REGISTRY.register("domian_portal", () -> new DomianPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
