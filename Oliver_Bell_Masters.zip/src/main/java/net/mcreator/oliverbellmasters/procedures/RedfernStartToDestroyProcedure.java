package net.mcreator.oliverbellmasters.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;

import net.mcreator.oliverbellmasters.OliverBellMastersMod;

public class RedfernStartToDestroyProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		OliverBellMastersMod.queueServerWork(60, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 100, Level.ExplosionInteraction.NONE);
		});
	}
}
