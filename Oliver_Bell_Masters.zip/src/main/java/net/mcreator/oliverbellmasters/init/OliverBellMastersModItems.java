
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliverbellmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.oliverbellmasters.item.RedlighterItem;
import net.mcreator.oliverbellmasters.item.RedingotItem;
import net.mcreator.oliverbellmasters.item.ReddimensionItem;
import net.mcreator.oliverbellmasters.item.RedItem;
import net.mcreator.oliverbellmasters.item.OliverswordItem;
import net.mcreator.oliverbellmasters.item.HItem;
import net.mcreator.oliverbellmasters.item.BlueItem;
import net.mcreator.oliverbellmasters.item.BloodItem;
import net.mcreator.oliverbellmasters.OliverBellMastersMod;

public class OliverBellMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OliverBellMastersMod.MODID);
	public static final RegistryObject<Item> H = REGISTRY.register("h", () -> new HItem());
	public static final RegistryObject<Item> HOREBLOCK = block(OliverBellMastersModBlocks.HOREBLOCK);
	public static final RegistryObject<Item> REDINGOT = REGISTRY.register("redingot", () -> new RedingotItem());
	public static final RegistryObject<Item> BOOM = block(OliverBellMastersModBlocks.BOOM);
	public static final RegistryObject<Item> BRICKBLOCK = block(OliverBellMastersModBlocks.BRICKBLOCK);
	public static final RegistryObject<Item> REDLIGHTER = REGISTRY.register("redlighter", () -> new RedlighterItem());
	public static final RegistryObject<Item> REDDIMENSION = REGISTRY.register("reddimension", () -> new ReddimensionItem());
	public static final RegistryObject<Item> BLUE_HELMET = REGISTRY.register("blue_helmet", () -> new BlueItem.Helmet());
	public static final RegistryObject<Item> BLUE_CHESTPLATE = REGISTRY.register("blue_chestplate", () -> new BlueItem.Chestplate());
	public static final RegistryObject<Item> BLUE_LEGGINGS = REGISTRY.register("blue_leggings", () -> new BlueItem.Leggings());
	public static final RegistryObject<Item> BLUE_BOOTS = REGISTRY.register("blue_boots", () -> new BlueItem.Boots());
	public static final RegistryObject<Item> REDSLIME_SPAWN_EGG = REGISTRY.register("redslime_spawn_egg", () -> new ForgeSpawnEggItem(OliverBellMastersModEntities.REDSLIME, -65536, -6750208, new Item.Properties()));
	public static final RegistryObject<Item> OLIVERSWORD = REGISTRY.register("oliversword", () -> new OliverswordItem());
	public static final RegistryObject<Item> REDFERN = block(OliverBellMastersModBlocks.REDFERN);
	public static final RegistryObject<Item> REDGRASS = block(OliverBellMastersModBlocks.REDGRASS);
	public static final RegistryObject<Item> REDLOG = block(OliverBellMastersModBlocks.REDLOG);
	public static final RegistryObject<Item> REDLEAF = block(OliverBellMastersModBlocks.REDLEAF);
	public static final RegistryObject<Item> REDDIRT = block(OliverBellMastersModBlocks.REDDIRT);
	public static final RegistryObject<Item> BLOOD_BUCKET = REGISTRY.register("blood_bucket", () -> new BloodItem());
	public static final RegistryObject<Item> RED_BUCKET = REGISTRY.register("red_bucket", () -> new RedItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
