
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliverbellmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.oliverbellmasters.potion.RainMobEffect;
import net.mcreator.oliverbellmasters.OliverBellMastersMod;

public class OliverBellMastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, OliverBellMastersMod.MODID);
	public static final RegistryObject<MobEffect> RAIN = REGISTRY.register("rain", () -> new RainMobEffect());
}
