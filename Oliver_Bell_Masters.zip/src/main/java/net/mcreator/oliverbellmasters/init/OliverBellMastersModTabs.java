
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliverbellmasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.oliverbellmasters.OliverBellMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OliverBellMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OliverBellMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(OliverBellMastersModBlocks.BOOM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(OliverBellMastersModItems.BLUE_HELMET.get());
			tabData.accept(OliverBellMastersModItems.BLUE_CHESTPLATE.get());
			tabData.accept(OliverBellMastersModItems.BLUE_LEGGINGS.get());
			tabData.accept(OliverBellMastersModItems.BLUE_BOOTS.get());
			tabData.accept(OliverBellMastersModItems.OLIVERSWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(OliverBellMastersModItems.REDSLIME_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(OliverBellMastersModItems.H.get());
			tabData.accept(OliverBellMastersModItems.REDINGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(OliverBellMastersModBlocks.HOREBLOCK.get().asItem());
			tabData.accept(OliverBellMastersModBlocks.REDFERN.get().asItem());
			tabData.accept(OliverBellMastersModBlocks.REDGRASS.get().asItem());
			tabData.accept(OliverBellMastersModBlocks.REDLOG.get().asItem());
			tabData.accept(OliverBellMastersModBlocks.REDLEAF.get().asItem());
			tabData.accept(OliverBellMastersModBlocks.REDDIRT.get().asItem());
			tabData.accept(OliverBellMastersModItems.BLOOD_BUCKET.get());
			tabData.accept(OliverBellMastersModItems.RED_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(OliverBellMastersModItems.REDLIGHTER.get());
			tabData.accept(OliverBellMastersModItems.REDDIMENSION.get());
		}
	}
}
