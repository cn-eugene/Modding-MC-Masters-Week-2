
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliverbellmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.oliverbellmasters.block.RedlogBlock;
import net.mcreator.oliverbellmasters.block.RedleafBlock;
import net.mcreator.oliverbellmasters.block.RedgrassBlock;
import net.mcreator.oliverbellmasters.block.RedfernBlock;
import net.mcreator.oliverbellmasters.block.ReddirtBlock;
import net.mcreator.oliverbellmasters.block.ReddimensionPortalBlock;
import net.mcreator.oliverbellmasters.block.RedBlock;
import net.mcreator.oliverbellmasters.block.HoreblockBlock;
import net.mcreator.oliverbellmasters.block.BrickblockBlock;
import net.mcreator.oliverbellmasters.block.BoomBlock;
import net.mcreator.oliverbellmasters.block.BloodBlock;
import net.mcreator.oliverbellmasters.OliverBellMastersMod;

public class OliverBellMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OliverBellMastersMod.MODID);
	public static final RegistryObject<Block> HOREBLOCK = REGISTRY.register("horeblock", () -> new HoreblockBlock());
	public static final RegistryObject<Block> BOOM = REGISTRY.register("boom", () -> new BoomBlock());
	public static final RegistryObject<Block> BRICKBLOCK = REGISTRY.register("brickblock", () -> new BrickblockBlock());
	public static final RegistryObject<Block> REDDIMENSION_PORTAL = REGISTRY.register("reddimension_portal", () -> new ReddimensionPortalBlock());
	public static final RegistryObject<Block> REDFERN = REGISTRY.register("redfern", () -> new RedfernBlock());
	public static final RegistryObject<Block> REDGRASS = REGISTRY.register("redgrass", () -> new RedgrassBlock());
	public static final RegistryObject<Block> REDLOG = REGISTRY.register("redlog", () -> new RedlogBlock());
	public static final RegistryObject<Block> REDLEAF = REGISTRY.register("redleaf", () -> new RedleafBlock());
	public static final RegistryObject<Block> REDDIRT = REGISTRY.register("reddirt", () -> new ReddirtBlock());
	public static final RegistryObject<Block> BLOOD = REGISTRY.register("blood", () -> new BloodBlock());
	public static final RegistryObject<Block> RED = REGISTRY.register("red", () -> new RedBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
