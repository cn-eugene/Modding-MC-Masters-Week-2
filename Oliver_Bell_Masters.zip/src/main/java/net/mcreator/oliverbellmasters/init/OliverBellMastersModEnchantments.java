
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.oliverbellmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.oliverbellmasters.enchantment.EEnchantment;
import net.mcreator.oliverbellmasters.OliverBellMastersMod;

public class OliverBellMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, OliverBellMastersMod.MODID);
	public static final RegistryObject<Enchantment> E = REGISTRY.register("e", () -> new EEnchantment());
}
