
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.oliverbellmasters.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class OliverBellMastersModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.ARMORER) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.APPLE, 62), new ItemStack(OliverBellMastersModItems.REDSLIME_SPAWN_EGG.get(), 14), new ItemStack(OliverBellMastersModItems.OLIVERSWORD.get(), 31), 74, 110, 0.12f));
		}
	}
}
