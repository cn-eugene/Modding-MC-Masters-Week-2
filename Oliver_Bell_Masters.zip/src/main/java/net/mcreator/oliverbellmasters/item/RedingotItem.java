
package net.mcreator.oliverbellmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RedingotItem extends Item {
	public RedingotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
