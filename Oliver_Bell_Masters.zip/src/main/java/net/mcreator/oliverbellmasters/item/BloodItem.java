
package net.mcreator.oliverbellmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.oliverbellmasters.init.OliverBellMastersModFluids;

public class BloodItem extends BucketItem {
	public BloodItem() {
		super(OliverBellMastersModFluids.BLOOD, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
