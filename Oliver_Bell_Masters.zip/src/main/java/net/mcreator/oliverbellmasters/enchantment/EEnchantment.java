
package net.mcreator.oliverbellmasters.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;

public class EEnchantment extends Enchantment {
	public EEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.COMMON, EnchantmentCategory.WEAPON, slots);
	}

	@Override
	public int getMinLevel() {
		return 4;
	}

	@Override
	public int getMaxLevel() {
		return 5;
	}
}
