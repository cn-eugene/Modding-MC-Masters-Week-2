
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabellmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.matildabellmasters.block.SagePlankBlock;
import net.mcreator.matildabellmasters.block.SageLogBlock;
import net.mcreator.matildabellmasters.block.NoNameOreBlock;
import net.mcreator.matildabellmasters.block.NoNameDimensionPortalBlock;
import net.mcreator.matildabellmasters.block.NewdirtBlock;
import net.mcreator.matildabellmasters.block.MarigoldBlock;
import net.mcreator.matildabellmasters.block.LeavesofgreenBlock;
import net.mcreator.matildabellmasters.block.FernBlock;
import net.mcreator.matildabellmasters.block.DirtWorldPortalBlock;
import net.mcreator.matildabellmasters.block.BigBoxOfDoomBlock;
import net.mcreator.matildabellmasters.block.BabyGrassBlockBlock;
import net.mcreator.matildabellmasters.MatildabellmastersMod;

public class MatildabellmastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, MatildabellmastersMod.MODID);
	public static final DeferredHolder<Block, Block> NO_NAME_ORE = REGISTRY.register("no_name_ore", () -> new NoNameOreBlock());
	public static final DeferredHolder<Block, Block> BIG_BOX_OF_DOOM = REGISTRY.register("big_box_of_doom", () -> new BigBoxOfDoomBlock());
	public static final DeferredHolder<Block, Block> NO_NAME_DIMENSION_PORTAL = REGISTRY.register("no_name_dimension_portal", () -> new NoNameDimensionPortalBlock());
	public static final DeferredHolder<Block, Block> DIRT_WORLD_PORTAL = REGISTRY.register("dirt_world_portal", () -> new DirtWorldPortalBlock());
	public static final DeferredHolder<Block, Block> MARIGOLD = REGISTRY.register("marigold", () -> new MarigoldBlock());
	public static final DeferredHolder<Block, Block> FERN = REGISTRY.register("fern", () -> new FernBlock());
	public static final DeferredHolder<Block, Block> BABY_GRASS_BLOCK = REGISTRY.register("baby_grass_block", () -> new BabyGrassBlockBlock());
	public static final DeferredHolder<Block, Block> SAGE_LOG = REGISTRY.register("sage_log", () -> new SageLogBlock());
	public static final DeferredHolder<Block, Block> SAGE_PLANK = REGISTRY.register("sage_plank", () -> new SagePlankBlock());
	public static final DeferredHolder<Block, Block> LEAVESOFGREEN = REGISTRY.register("leavesofgreen", () -> new LeavesofgreenBlock());
	public static final DeferredHolder<Block, Block> NEWDIRT = REGISTRY.register("newdirt", () -> new NewdirtBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
