
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabellmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.matildabellmasters.MatildabellmastersMod;

public class MatildabellmastersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, MatildabellmastersMod.MODID);
	public static final DeferredHolder<Potion, Potion> INSTANT_DEATH_POTION = REGISTRY.register("instant_death_potion", () -> new Potion(new MobEffectInstance(MatildabellmastersModMobEffects.INSTANT_DEATH.get(), 3600, 0, false, true)));
}
