
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabellmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.matildabellmasters.MatildabellmastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MatildabellmastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MatildabellmastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(MatildabellmastersModBlocks.SAGE_LOG.get().asItem());
			tabData.accept(MatildabellmastersModBlocks.SAGE_PLANK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(MatildabellmastersModBlocks.BIG_BOX_OF_DOOM.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MatildabellmastersModItems.NO_NAME_SWORD.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_ARMOR_HELMET.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_ARMOR_CHESTPLATE.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_ARMOR_LEGGINGS.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MatildabellmastersModItems.WILD_CAT_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MatildabellmastersModItems.NO_NAME_GEM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MatildabellmastersModBlocks.NO_NAME_ORE.get().asItem());
			tabData.accept(MatildabellmastersModBlocks.MARIGOLD.get().asItem());
			tabData.accept(MatildabellmastersModBlocks.FERN.get().asItem());
			tabData.accept(MatildabellmastersModBlocks.BABY_GRASS_BLOCK.get().asItem());
			tabData.accept(MatildabellmastersModBlocks.LEAVESOFGREEN.get().asItem());
			tabData.accept(MatildabellmastersModBlocks.NEWDIRT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MatildabellmastersModItems.NO_NAME_PICKAXE.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_AXE.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_SHOVEL.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_HOE.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_SHIELD.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_ROD.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_SHEARS.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_LIGHTER.get());
			tabData.accept(MatildabellmastersModItems.NO_NAME_DIMENSION.get());
			tabData.accept(MatildabellmastersModItems.DIRT_WORLD.get());
		}
	}
}
