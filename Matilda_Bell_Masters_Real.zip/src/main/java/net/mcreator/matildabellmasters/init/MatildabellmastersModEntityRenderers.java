
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabellmasters.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.matildabellmasters.client.renderer.WildCatRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MatildabellmastersModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MatildabellmastersModEntities.WILD_CAT.get(), WildCatRenderer::new);
	}
}
