
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabellmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.matildabellmasters.item.NoNameSwordItem;
import net.mcreator.matildabellmasters.item.NoNameShovelItem;
import net.mcreator.matildabellmasters.item.NoNameShieldItem;
import net.mcreator.matildabellmasters.item.NoNameShearsItem;
import net.mcreator.matildabellmasters.item.NoNameRodItem;
import net.mcreator.matildabellmasters.item.NoNamePickaxeItem;
import net.mcreator.matildabellmasters.item.NoNameLighterItem;
import net.mcreator.matildabellmasters.item.NoNameHoeItem;
import net.mcreator.matildabellmasters.item.NoNameGemItem;
import net.mcreator.matildabellmasters.item.NoNameDimensionItem;
import net.mcreator.matildabellmasters.item.NoNameAxeItem;
import net.mcreator.matildabellmasters.item.NoNameArmorItem;
import net.mcreator.matildabellmasters.item.DirtWorldItem;
import net.mcreator.matildabellmasters.item.DirtLighterItem;
import net.mcreator.matildabellmasters.MatildabellmastersMod;

public class MatildabellmastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, MatildabellmastersMod.MODID);
	public static final DeferredHolder<Item, Item> NO_NAME_ORE = block(MatildabellmastersModBlocks.NO_NAME_ORE);
	public static final DeferredHolder<Item, Item> NO_NAME_GEM = REGISTRY.register("no_name_gem", () -> new NoNameGemItem());
	public static final DeferredHolder<Item, Item> NO_NAME_PICKAXE = REGISTRY.register("no_name_pickaxe", () -> new NoNamePickaxeItem());
	public static final DeferredHolder<Item, Item> NO_NAME_AXE = REGISTRY.register("no_name_axe", () -> new NoNameAxeItem());
	public static final DeferredHolder<Item, Item> NO_NAME_SWORD = REGISTRY.register("no_name_sword", () -> new NoNameSwordItem());
	public static final DeferredHolder<Item, Item> NO_NAME_SHOVEL = REGISTRY.register("no_name_shovel", () -> new NoNameShovelItem());
	public static final DeferredHolder<Item, Item> NO_NAME_HOE = REGISTRY.register("no_name_hoe", () -> new NoNameHoeItem());
	public static final DeferredHolder<Item, Item> NO_NAME_SHIELD = REGISTRY.register("no_name_shield", () -> new NoNameShieldItem());
	public static final DeferredHolder<Item, Item> NO_NAME_ROD = REGISTRY.register("no_name_rod", () -> new NoNameRodItem());
	public static final DeferredHolder<Item, Item> NO_NAME_SHEARS = REGISTRY.register("no_name_shears", () -> new NoNameShearsItem());
	public static final DeferredHolder<Item, Item> NO_NAME_LIGHTER = REGISTRY.register("no_name_lighter", () -> new NoNameLighterItem());
	public static final DeferredHolder<Item, Item> BIG_BOX_OF_DOOM = block(MatildabellmastersModBlocks.BIG_BOX_OF_DOOM);
	public static final DeferredHolder<Item, Item> NO_NAME_ARMOR_HELMET = REGISTRY.register("no_name_armor_helmet", () -> new NoNameArmorItem.Helmet());
	public static final DeferredHolder<Item, Item> NO_NAME_ARMOR_CHESTPLATE = REGISTRY.register("no_name_armor_chestplate", () -> new NoNameArmorItem.Chestplate());
	public static final DeferredHolder<Item, Item> NO_NAME_ARMOR_LEGGINGS = REGISTRY.register("no_name_armor_leggings", () -> new NoNameArmorItem.Leggings());
	public static final DeferredHolder<Item, Item> NO_NAME_ARMOR_BOOTS = REGISTRY.register("no_name_armor_boots", () -> new NoNameArmorItem.Boots());
	public static final DeferredHolder<Item, Item> NO_NAME_DIMENSION = REGISTRY.register("no_name_dimension", () -> new NoNameDimensionItem());
	public static final DeferredHolder<Item, Item> DIRT_LIGHTER = REGISTRY.register("dirt_lighter", () -> new DirtLighterItem());
	public static final DeferredHolder<Item, Item> DIRT_WORLD = REGISTRY.register("dirt_world", () -> new DirtWorldItem());
	public static final DeferredHolder<Item, Item> WILD_CAT_SPAWN_EGG = REGISTRY.register("wild_cat_spawn_egg", () -> new DeferredSpawnEggItem(MatildabellmastersModEntities.WILD_CAT, -10066330, -13092808, new Item.Properties()));
	public static final DeferredHolder<Item, Item> MARIGOLD = block(MatildabellmastersModBlocks.MARIGOLD);
	public static final DeferredHolder<Item, Item> FERN = block(MatildabellmastersModBlocks.FERN);
	public static final DeferredHolder<Item, Item> BABY_GRASS_BLOCK = block(MatildabellmastersModBlocks.BABY_GRASS_BLOCK);
	public static final DeferredHolder<Item, Item> SAGE_LOG = block(MatildabellmastersModBlocks.SAGE_LOG);
	public static final DeferredHolder<Item, Item> SAGE_PLANK = block(MatildabellmastersModBlocks.SAGE_PLANK);
	public static final DeferredHolder<Item, Item> LEAVESOFGREEN = block(MatildabellmastersModBlocks.LEAVESOFGREEN);
	public static final DeferredHolder<Item, Item> NEWDIRT = block(MatildabellmastersModBlocks.NEWDIRT);

	// Start of user code block custom items
	// End of user code block custom items
	public static void register(IEventBus bus) {
		REGISTRY.register(bus);
	}

	private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(NO_NAME_SHIELD.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
			});
		}
	}
}
