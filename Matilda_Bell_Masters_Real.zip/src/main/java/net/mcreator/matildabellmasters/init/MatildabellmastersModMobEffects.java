
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.matildabellmasters.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.matildabellmasters.potion.InstantDeathMobEffect;
import net.mcreator.matildabellmasters.MatildabellmastersMod;

public class MatildabellmastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, MatildabellmastersMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> INSTANT_DEATH = REGISTRY.register("instant_death", () -> new InstantDeathMobEffect());
}
