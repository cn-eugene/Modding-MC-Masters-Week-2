
package net.mcreator.matildabellmasters.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;

import net.mcreator.matildabellmasters.init.MatildabellmastersModItems;

public class NoNameAxeItem extends AxeItem {
	public NoNameAxeItem() {
		super(new Tier() {
			public int getUses() {
				return 10000;
			}

			public float getSpeed() {
				return 100f;
			}

			public float getAttackDamageBonus() {
				return 88f;
			}

			public int getLevel() {
				return 20;
			}

			public int getEnchantmentValue() {
				return 140;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(MatildabellmastersModItems.NO_NAME_GEM.get()));
			}
		}, 1, 5f, new Item.Properties());
	}
}
