
package net.mcreator.matildabellmasters.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class NoNameShieldItem extends ShieldItem {
	public NoNameShieldItem() {
		super(new Item.Properties().durability(10000));
	}
}
