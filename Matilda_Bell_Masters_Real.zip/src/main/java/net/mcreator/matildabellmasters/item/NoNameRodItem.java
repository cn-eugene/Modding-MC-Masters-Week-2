
package net.mcreator.matildabellmasters.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.FishingRodItem;

public class NoNameRodItem extends FishingRodItem {
	public NoNameRodItem() {
		super(new Item.Properties().durability(10000));
	}

	@Override
	public int getEnchantmentValue() {
		return 5;
	}
}
