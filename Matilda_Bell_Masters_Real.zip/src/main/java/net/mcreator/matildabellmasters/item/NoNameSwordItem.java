
package net.mcreator.matildabellmasters.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.matildabellmasters.init.MatildabellmastersModItems;

public class NoNameSwordItem extends SwordItem {
	public NoNameSwordItem() {
		super(new Tier() {
			public int getUses() {
				return 10000;
			}

			public float getSpeed() {
				return 100f;
			}

			public float getAttackDamageBonus() {
				return 996f;
			}

			public int getLevel() {
				return 20;
			}

			public int getEnchantmentValue() {
				return 140;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(MatildabellmastersModItems.NO_NAME_GEM.get()));
			}
		}, 3, 96f, new Item.Properties());
	}
}
