
package net.mcreator.matildabellmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.OcelotModel;

import net.mcreator.matildabellmasters.entity.WildCatEntity;

public class WildCatRenderer extends MobRenderer<WildCatEntity, OcelotModel<WildCatEntity>> {
	public WildCatRenderer(EntityRendererProvider.Context context) {
		super(context, new OcelotModel(context.bakeLayer(ModelLayers.OCELOT)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(WildCatEntity entity) {
		return new ResourceLocation("matildabellmasters:textures/entities/cat.png");
	}
}
