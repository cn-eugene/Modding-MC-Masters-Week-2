
package net.mcreator.matildabellmasters.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.matildabellmasters.procedures.InstantDeathEffectStartedappliedProcedure;

public class InstantDeathMobEffect extends MobEffect {
	public InstantDeathMobEffect() {
		super(MobEffectCategory.HARMFUL, -11925754);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		InstantDeathEffectStartedappliedProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		InstantDeathEffectStartedappliedProcedure.execute(entity.level(), entity);
	}
}
