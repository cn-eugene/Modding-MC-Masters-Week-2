
package net.mcreator.loganlashleymasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RawCoplousionItem extends Item {
	public RawCoplousionItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
