
package net.mcreator.loganlashleymasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ArrowofworldsItem extends Item {
	public ArrowofworldsItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.EPIC));
	}
}
