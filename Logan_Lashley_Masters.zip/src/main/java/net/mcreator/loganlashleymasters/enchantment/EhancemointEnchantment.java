
package net.mcreator.loganlashleymasters.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.loganlashleymasters.init.LoganLashleyMastersModItems;

public class EhancemointEnchantment extends Enchantment {
	public EhancemointEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.WEAPON, slots);
	}

	@Override
	public int getMinLevel() {
		return 30;
	}

	@Override
	public int getMaxLevel() {
		return 30;
	}

	@Override
	public boolean canApplyAtEnchantingTable(ItemStack itemstack) {
		return Ingredient.of(new ItemStack(LoganLashleyMastersModItems.THEPEBBLEPARTTWO.get())).test(itemstack);
	}
}
