
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.loganlashleymasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.loganlashleymasters.enchantment.EhancemointEnchantment;
import net.mcreator.loganlashleymasters.LoganLashleyMastersMod;

public class LoganLashleyMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, LoganLashleyMastersMod.MODID);
	public static final RegistryObject<Enchantment> EHANCEMOINT = REGISTRY.register("ehancemoint", () -> new EhancemointEnchantment());
}
