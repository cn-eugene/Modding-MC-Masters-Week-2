
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.loganlashleymasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.loganlashleymasters.potion.RAINOFAROowMobEffect;
import net.mcreator.loganlashleymasters.LoganLashleyMastersMod;

public class LoganLashleyMastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, LoganLashleyMastersMod.MODID);
	public static final RegistryObject<MobEffect> RAINOFAR_OOW = REGISTRY.register("rainofar_oow", () -> new RAINOFAROowMobEffect());
}
