
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.loganlashleymasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.loganlashleymasters.block.GibltyGorbBlock;
import net.mcreator.loganlashleymasters.block.DedloogBlock;
import net.mcreator.loganlashleymasters.block.Ded4Block;
import net.mcreator.loganlashleymasters.block.DeadgrassBlock;
import net.mcreator.loganlashleymasters.block.CoplousionoreBlock;
import net.mcreator.loganlashleymasters.LoganLashleyMastersMod;

public class LoganLashleyMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LoganLashleyMastersMod.MODID);
	public static final RegistryObject<Block> COPLOUSIONORE = REGISTRY.register("coplousionore", () -> new CoplousionoreBlock());
	public static final RegistryObject<Block> GIBLTY_GORB = REGISTRY.register("giblty_gorb", () -> new GibltyGorbBlock());
	public static final RegistryObject<Block> DEADGRASS = REGISTRY.register("deadgrass", () -> new DeadgrassBlock());
	public static final RegistryObject<Block> DEDLOOG = REGISTRY.register("dedloog", () -> new DedloogBlock());
	public static final RegistryObject<Block> DED_4 = REGISTRY.register("ded_4", () -> new Ded4Block());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			GibltyGorbBlock.blockColorLoad(event);
		}
	}
}
