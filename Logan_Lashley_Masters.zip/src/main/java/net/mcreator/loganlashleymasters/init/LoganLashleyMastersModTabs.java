
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.loganlashleymasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.loganlashleymasters.LoganLashleyMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LoganLashleyMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LoganLashleyMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LoganLashleyMastersModItems.GREG.get());
			tabData.accept(LoganLashleyMastersModItems.GREGUPGRADE.get());
			tabData.accept(LoganLashleyMastersModItems.ARROWOFWORLDS.get());
			tabData.accept(LoganLashleyMastersModItems.BOW.get());
			tabData.accept(LoganLashleyMastersModItems.THEPEBBLEPARTTWO.get());
			tabData.accept(LoganLashleyMastersModItems.GREG_2.get());
			tabData.accept(LoganLashleyMastersModItems.ARMOO_HELMET.get());
			tabData.accept(LoganLashleyMastersModItems.ARMOO_CHESTPLATE.get());
			tabData.accept(LoganLashleyMastersModItems.ARMOO_LEGGINGS.get());
			tabData.accept(LoganLashleyMastersModItems.ARMOO_BOOTS.get());
			tabData.accept(LoganLashleyMastersModItems.WIZORDSTAFF.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LoganLashleyMastersModItems.WIZORD_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(LoganLashleyMastersModItems.CUPLOUSION.get());
			tabData.accept(LoganLashleyMastersModItems.RAW_COPLOUSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LoganLashleyMastersModBlocks.COPLOUSIONORE.get().asItem());
			tabData.accept(LoganLashleyMastersModBlocks.GIBLTY_GORB.get().asItem());
			tabData.accept(LoganLashleyMastersModBlocks.DEADGRASS.get().asItem());
			tabData.accept(LoganLashleyMastersModBlocks.DEDLOOG.get().asItem());
			tabData.accept(LoganLashleyMastersModBlocks.DED_4.get().asItem());
		}
	}
}
