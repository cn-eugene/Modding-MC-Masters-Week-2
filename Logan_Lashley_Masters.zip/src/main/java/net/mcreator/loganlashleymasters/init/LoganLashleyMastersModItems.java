
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.loganlashleymasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.loganlashleymasters.item.WizordstaffItem;
import net.mcreator.loganlashleymasters.item.THEPEBBLEPARTTWOItem;
import net.mcreator.loganlashleymasters.item.RawCoplousionItem;
import net.mcreator.loganlashleymasters.item.GregupgradeItem;
import net.mcreator.loganlashleymasters.item.GregItem;
import net.mcreator.loganlashleymasters.item.Greg2Item;
import net.mcreator.loganlashleymasters.item.CuplousionItem;
import net.mcreator.loganlashleymasters.item.BowItem;
import net.mcreator.loganlashleymasters.item.ArrowofworldsItem;
import net.mcreator.loganlashleymasters.item.ArmooItem;
import net.mcreator.loganlashleymasters.LoganLashleyMastersMod;

public class LoganLashleyMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LoganLashleyMastersMod.MODID);
	public static final RegistryObject<Item> CUPLOUSION = REGISTRY.register("cuplousion", () -> new CuplousionItem());
	public static final RegistryObject<Item> COPLOUSIONORE = block(LoganLashleyMastersModBlocks.COPLOUSIONORE);
	public static final RegistryObject<Item> RAW_COPLOUSION = REGISTRY.register("raw_coplousion", () -> new RawCoplousionItem());
	public static final RegistryObject<Item> GREG = REGISTRY.register("greg", () -> new GregItem());
	public static final RegistryObject<Item> GREGUPGRADE = REGISTRY.register("gregupgrade", () -> new GregupgradeItem());
	public static final RegistryObject<Item> ARROWOFWORLDS = REGISTRY.register("arrowofworlds", () -> new ArrowofworldsItem());
	public static final RegistryObject<Item> BOW = REGISTRY.register("bow", () -> new BowItem());
	public static final RegistryObject<Item> THEPEBBLEPARTTWO = REGISTRY.register("thepebbleparttwo", () -> new THEPEBBLEPARTTWOItem());
	public static final RegistryObject<Item> GREG_2 = REGISTRY.register("greg_2", () -> new Greg2Item());
	public static final RegistryObject<Item> ARMOO_HELMET = REGISTRY.register("armoo_helmet", () -> new ArmooItem.Helmet());
	public static final RegistryObject<Item> ARMOO_CHESTPLATE = REGISTRY.register("armoo_chestplate", () -> new ArmooItem.Chestplate());
	public static final RegistryObject<Item> ARMOO_LEGGINGS = REGISTRY.register("armoo_leggings", () -> new ArmooItem.Leggings());
	public static final RegistryObject<Item> ARMOO_BOOTS = REGISTRY.register("armoo_boots", () -> new ArmooItem.Boots());
	public static final RegistryObject<Item> WIZORD_SPAWN_EGG = REGISTRY.register("wizord_spawn_egg", () -> new ForgeSpawnEggItem(LoganLashleyMastersModEntities.WIZORD, -10053121, -13312, new Item.Properties()));
	public static final RegistryObject<Item> WIZORDSTAFF = REGISTRY.register("wizordstaff", () -> new WizordstaffItem());
	public static final RegistryObject<Item> GIBLTY_GORB = block(LoganLashleyMastersModBlocks.GIBLTY_GORB);
	public static final RegistryObject<Item> DEADGRASS = block(LoganLashleyMastersModBlocks.DEADGRASS);
	public static final RegistryObject<Item> DEDLOOG = block(LoganLashleyMastersModBlocks.DEDLOOG);
	public static final RegistryObject<Item> DED_4 = block(LoganLashleyMastersModBlocks.DED_4);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
