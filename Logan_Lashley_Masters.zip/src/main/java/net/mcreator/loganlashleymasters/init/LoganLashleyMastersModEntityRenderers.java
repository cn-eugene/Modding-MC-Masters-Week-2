
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.loganlashleymasters.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.loganlashleymasters.client.renderer.WizordRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class LoganLashleyMastersModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(LoganLashleyMastersModEntities.ARROWOFDESTRUCTION.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(LoganLashleyMastersModEntities.THEPEBBLE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(LoganLashleyMastersModEntities.ARROOOW.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(LoganLashleyMastersModEntities.WIZORD.get(), WizordRenderer::new);
	}
}
