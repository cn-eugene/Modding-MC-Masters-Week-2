
package net.mcreator.anderskungysmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class EmeraldingotItem extends Item {
	public EmeraldingotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
