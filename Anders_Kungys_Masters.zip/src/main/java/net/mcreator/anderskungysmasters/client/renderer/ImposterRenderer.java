
package net.mcreator.anderskungysmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.anderskungysmasters.entity.ImposterEntity;
import net.mcreator.anderskungysmasters.client.model.ModelImposter;

public class ImposterRenderer extends MobRenderer<ImposterEntity, ModelImposter<ImposterEntity>> {
	public ImposterRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelImposter(context.bakeLayer(ModelImposter.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ImposterEntity entity) {
		return new ResourceLocation("anders_kungys_masters:textures/entities/texture.png");
	}
}
