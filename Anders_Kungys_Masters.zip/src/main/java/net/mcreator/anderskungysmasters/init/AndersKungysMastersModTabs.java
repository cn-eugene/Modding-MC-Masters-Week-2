
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AndersKungysMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AndersKungysMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(AndersKungysMastersModBlocks.SANSATTACK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AndersKungysMastersModItems.EMERALDSWORD.get());
			tabData.accept(AndersKungysMastersModItems.B_HELMET.get());
			tabData.accept(AndersKungysMastersModItems.B_CHESTPLATE.get());
			tabData.accept(AndersKungysMastersModItems.B_LEGGINGS.get());
			tabData.accept(AndersKungysMastersModItems.B_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AndersKungysMastersModItems.SANS_SPAWN_EGG.get());
			tabData.accept(AndersKungysMastersModItems.PAPYRUS_SPAWN_EGG.get());
			tabData.accept(AndersKungysMastersModItems.IMPOSTER_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AndersKungysMastersModItems.EMERALDS.get());
			tabData.accept(AndersKungysMastersModItems.EMERALDINGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AndersKungysMastersModBlocks.EMERRALDSBLOCK.get().asItem());
			tabData.accept(AndersKungysMastersModBlocks.YEEL.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AndersKungysMastersModItems.TROMBONE.get());
		}
	}
}
