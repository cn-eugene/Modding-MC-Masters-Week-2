
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.anderskungysmasters.potion.BoneMobEffect;
import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

public class AndersKungysMastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, AndersKungysMastersMod.MODID);
	public static final RegistryObject<MobEffect> BONE = REGISTRY.register("bone", () -> new BoneMobEffect());
}
