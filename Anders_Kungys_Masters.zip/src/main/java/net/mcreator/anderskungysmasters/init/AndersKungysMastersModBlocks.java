
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.anderskungysmasters.block.YeelBlock;
import net.mcreator.anderskungysmasters.block.WBlock;
import net.mcreator.anderskungysmasters.block.SansattackBlock;
import net.mcreator.anderskungysmasters.block.MmmmmmmmmBlock;
import net.mcreator.anderskungysmasters.block.EmerraldsblockBlock;
import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

public class AndersKungysMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, AndersKungysMastersMod.MODID);
	public static final RegistryObject<Block> EMERRALDSBLOCK = REGISTRY.register("emerraldsblock", () -> new EmerraldsblockBlock());
	public static final RegistryObject<Block> SANSATTACK = REGISTRY.register("sansattack", () -> new SansattackBlock());
	public static final RegistryObject<Block> YEEL = REGISTRY.register("yeel", () -> new YeelBlock());
	public static final RegistryObject<Block> MMMMMMMMM = REGISTRY.register("mmmmmmmmm", () -> new MmmmmmmmmBlock());
	public static final RegistryObject<Block> W = REGISTRY.register("w", () -> new WBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			YeelBlock.blockColorLoad(event);
		}
	}
}
