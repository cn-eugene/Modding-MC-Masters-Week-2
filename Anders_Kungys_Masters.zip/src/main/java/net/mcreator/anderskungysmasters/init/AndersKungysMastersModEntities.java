
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.anderskungysmasters.entity.SansEntity;
import net.mcreator.anderskungysmasters.entity.PapyrusEntity;
import net.mcreator.anderskungysmasters.entity.ImposterEntity;
import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class AndersKungysMastersModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, AndersKungysMastersMod.MODID);
	public static final RegistryObject<EntityType<SansEntity>> SANS = register("sans",
			EntityType.Builder.<SansEntity>of(SansEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SansEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<PapyrusEntity>> PAPYRUS = register("papyrus",
			EntityType.Builder.<PapyrusEntity>of(PapyrusEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PapyrusEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ImposterEntity>> IMPOSTER = register("imposter",
			EntityType.Builder.<ImposterEntity>of(ImposterEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ImposterEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SansEntity.init();
			PapyrusEntity.init();
			ImposterEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SANS.get(), SansEntity.createAttributes().build());
		event.put(PAPYRUS.get(), PapyrusEntity.createAttributes().build());
		event.put(IMPOSTER.get(), ImposterEntity.createAttributes().build());
	}
}
