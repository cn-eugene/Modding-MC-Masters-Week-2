
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

public class AndersKungysMastersModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, AndersKungysMastersMod.MODID);
	public static final RegistryObject<SoundEvent> TROMBONE_SOUND = REGISTRY.register("trombone_sound", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("anders_kungys_masters", "trombone_sound")));
}
