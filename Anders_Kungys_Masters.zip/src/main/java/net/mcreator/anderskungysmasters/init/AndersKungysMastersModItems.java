
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.anderskungysmasters.item.TromboneItem;
import net.mcreator.anderskungysmasters.item.EmeraldswordItem;
import net.mcreator.anderskungysmasters.item.EmeraldsItem;
import net.mcreator.anderskungysmasters.item.EmeraldingotItem;
import net.mcreator.anderskungysmasters.item.BItem;
import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

public class AndersKungysMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AndersKungysMastersMod.MODID);
	public static final RegistryObject<Item> EMERALDS = REGISTRY.register("emeralds", () -> new EmeraldsItem());
	public static final RegistryObject<Item> EMERRALDSBLOCK = block(AndersKungysMastersModBlocks.EMERRALDSBLOCK);
	public static final RegistryObject<Item> EMERALDINGOT = REGISTRY.register("emeraldingot", () -> new EmeraldingotItem());
	public static final RegistryObject<Item> EMERALDSWORD = REGISTRY.register("emeraldsword", () -> new EmeraldswordItem());
	public static final RegistryObject<Item> TROMBONE = REGISTRY.register("trombone", () -> new TromboneItem());
	public static final RegistryObject<Item> SANSATTACK = block(AndersKungysMastersModBlocks.SANSATTACK);
	public static final RegistryObject<Item> B_HELMET = REGISTRY.register("b_helmet", () -> new BItem.Helmet());
	public static final RegistryObject<Item> B_CHESTPLATE = REGISTRY.register("b_chestplate", () -> new BItem.Chestplate());
	public static final RegistryObject<Item> B_LEGGINGS = REGISTRY.register("b_leggings", () -> new BItem.Leggings());
	public static final RegistryObject<Item> B_BOOTS = REGISTRY.register("b_boots", () -> new BItem.Boots());
	public static final RegistryObject<Item> SANS_SPAWN_EGG = REGISTRY.register("sans_spawn_egg", () -> new ForgeSpawnEggItem(AndersKungysMastersModEntities.SANS, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> YEEL = block(AndersKungysMastersModBlocks.YEEL);
	public static final RegistryObject<Item> MMMMMMMMM = block(AndersKungysMastersModBlocks.MMMMMMMMM);
	public static final RegistryObject<Item> W = block(AndersKungysMastersModBlocks.W);
	public static final RegistryObject<Item> PAPYRUS_SPAWN_EGG = REGISTRY.register("papyrus_spawn_egg", () -> new ForgeSpawnEggItem(AndersKungysMastersModEntities.PAPYRUS, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> IMPOSTER_SPAWN_EGG = REGISTRY.register("imposter_spawn_egg", () -> new ForgeSpawnEggItem(AndersKungysMastersModEntities.IMPOSTER, -1, -1, new Item.Properties()));

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
