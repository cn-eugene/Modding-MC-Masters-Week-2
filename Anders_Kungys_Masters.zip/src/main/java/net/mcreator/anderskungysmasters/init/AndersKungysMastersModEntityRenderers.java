
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.anderskungysmasters.client.renderer.SansRenderer;
import net.mcreator.anderskungysmasters.client.renderer.PapyrusRenderer;
import net.mcreator.anderskungysmasters.client.renderer.ImposterRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class AndersKungysMastersModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AndersKungysMastersModEntities.SANS.get(), SansRenderer::new);
		event.registerEntityRenderer(AndersKungysMastersModEntities.PAPYRUS.get(), PapyrusRenderer::new);
		event.registerEntityRenderer(AndersKungysMastersModEntities.IMPOSTER.get(), ImposterRenderer::new);
	}
}
