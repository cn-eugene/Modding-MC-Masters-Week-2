
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.anderskungysmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.anderskungysmasters.AndersKungysMastersMod;

public class AndersKungysMastersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, AndersKungysMastersMod.MODID);
	public static final RegistryObject<Potion> DAMAGED = REGISTRY.register("damaged", () -> new Potion(new MobEffectInstance(AndersKungysMastersModMobEffects.BONE.get(), 10000, 255, false, true)));
}
