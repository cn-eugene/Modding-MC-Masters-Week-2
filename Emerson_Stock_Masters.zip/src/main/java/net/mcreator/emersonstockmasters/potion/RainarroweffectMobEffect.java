
package net.mcreator.emersonstockmasters.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.emersonstockmasters.procedures.RainarrowpProcedure;

public class RainarroweffectMobEffect extends MobEffect {
	public RainarroweffectMobEffect() {
		super(MobEffectCategory.HARMFUL, -2488773);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		RainarrowpProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
