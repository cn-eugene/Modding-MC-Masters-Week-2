
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.emersonstockmasters.client.model.Modelmoonworm;
import net.mcreator.emersonstockmasters.client.model.Modelchunkycheese;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class EmersonStockMastersModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelmoonworm.LAYER_LOCATION, Modelmoonworm::createBodyLayer);
		event.registerLayerDefinition(Modelchunkycheese.LAYER_LOCATION, Modelchunkycheese::createBodyLayer);
	}
}
