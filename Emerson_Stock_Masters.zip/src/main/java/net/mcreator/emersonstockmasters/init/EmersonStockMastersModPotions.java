
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

public class EmersonStockMastersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, EmersonStockMastersMod.MODID);
	public static final RegistryObject<Potion> RAINARROW = REGISTRY.register("rainarrow", () -> new Potion(new MobEffectInstance(EmersonStockMastersModMobEffects.RAINARROWEFFECT.get(), 60, 4, false, true)));
}
