
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.emersonstockmasters.client.renderer.ChunkycheeseRenderer;
import net.mcreator.emersonstockmasters.client.renderer.CheesewormRenderer;
import net.mcreator.emersonstockmasters.client.renderer.CheeseslimeRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class EmersonStockMastersModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EmersonStockMastersModEntities.CHEESESLIME.get(), CheeseslimeRenderer::new);
		event.registerEntityRenderer(EmersonStockMastersModEntities.CHEESEWORM.get(), CheesewormRenderer::new);
		event.registerEntityRenderer(EmersonStockMastersModEntities.CHUNKYCHEESE.get(), ChunkycheeseRenderer::new);
	}
}
