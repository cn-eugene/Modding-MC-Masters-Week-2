
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EmersonStockMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EmersonStockMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(EmersonStockMastersModBlocks.EMERSONBOMB.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(EmersonStockMastersModItems.OPALSLAYERAXE.get());
			tabData.accept(EmersonStockMastersModItems.PICKLEARMOR_HELMET.get());
			tabData.accept(EmersonStockMastersModItems.PICKLEARMOR_CHESTPLATE.get());
			tabData.accept(EmersonStockMastersModItems.PICKLEARMOR_LEGGINGS.get());
			tabData.accept(EmersonStockMastersModItems.PICKLEARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(EmersonStockMastersModItems.CHEESESLIME_SPAWN_EGG.get());
			tabData.accept(EmersonStockMastersModItems.CHEESEWORM_SPAWN_EGG.get());
			tabData.accept(EmersonStockMastersModItems.CHUNKYCHEESE_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(EmersonStockMastersModItems.OPAL.get());
			tabData.accept(EmersonStockMastersModItems.OPALINGOT.get());
			tabData.accept(EmersonStockMastersModItems.PICKLE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(EmersonStockMastersModBlocks.CHEESEMOONBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(EmersonStockMastersModBlocks.OPALBLOCK.get().asItem());
			tabData.accept(EmersonStockMastersModBlocks.CHEESEPLANT.get().asItem());
			tabData.accept(EmersonStockMastersModBlocks.CHEESEDIRT.get().asItem());
			tabData.accept(EmersonStockMastersModBlocks.CHEESEBUSH.get().asItem());
			tabData.accept(EmersonStockMastersModBlocks.SPAWNCHEESEBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(EmersonStockMastersModItems.PEICEOCHEESE.get());
		}
	}
}
