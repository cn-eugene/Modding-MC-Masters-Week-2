
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.emersonstockmasters.potion.RainarroweffectMobEffect;
import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

public class EmersonStockMastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, EmersonStockMastersMod.MODID);
	public static final RegistryObject<MobEffect> RAINARROWEFFECT = REGISTRY.register("rainarroweffect", () -> new RainarroweffectMobEffect());
}
