
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.emersonstockmasters.entity.ChunkycheeseEntity;
import net.mcreator.emersonstockmasters.entity.CheesewormEntity;
import net.mcreator.emersonstockmasters.entity.CheeseslimeEntity;
import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class EmersonStockMastersModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, EmersonStockMastersMod.MODID);
	public static final RegistryObject<EntityType<CheeseslimeEntity>> CHEESESLIME = register("cheeseslime",
			EntityType.Builder.<CheeseslimeEntity>of(CheeseslimeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(70).setUpdateInterval(3).setCustomClientFactory(CheeseslimeEntity::new)

					.sized(1.1f, 1.1f));
	public static final RegistryObject<EntityType<CheesewormEntity>> CHEESEWORM = register("cheeseworm",
			EntityType.Builder.<CheesewormEntity>of(CheesewormEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(90).setUpdateInterval(3).setCustomClientFactory(CheesewormEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ChunkycheeseEntity>> CHUNKYCHEESE = register("chunkycheese", EntityType.Builder.<ChunkycheeseEntity>of(ChunkycheeseEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ChunkycheeseEntity::new).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			CheeseslimeEntity.init();
			CheesewormEntity.init();
			ChunkycheeseEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(CHEESESLIME.get(), CheeseslimeEntity.createAttributes().build());
		event.put(CHEESEWORM.get(), CheesewormEntity.createAttributes().build());
		event.put(CHUNKYCHEESE.get(), ChunkycheeseEntity.createAttributes().build());
	}
}
