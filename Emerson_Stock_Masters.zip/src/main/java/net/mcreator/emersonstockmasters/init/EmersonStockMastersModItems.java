
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DoubleHighBlockItem;
import net.minecraft.world.item.BlockItem;

import net.mcreator.emersonstockmasters.item.RawpickleshoesItem;
import net.mcreator.emersonstockmasters.item.PicklearmorItem;
import net.mcreator.emersonstockmasters.item.PickleItem;
import net.mcreator.emersonstockmasters.item.PeiceocheeseItem;
import net.mcreator.emersonstockmasters.item.OpalslayeraxeItem;
import net.mcreator.emersonstockmasters.item.OpalingotItem;
import net.mcreator.emersonstockmasters.item.OpalItem;
import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

public class EmersonStockMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EmersonStockMastersMod.MODID);
	public static final RegistryObject<Item> OPAL = REGISTRY.register("opal", () -> new OpalItem());
	public static final RegistryObject<Item> OPALBLOCK = block(EmersonStockMastersModBlocks.OPALBLOCK);
	public static final RegistryObject<Item> OPALINGOT = REGISTRY.register("opalingot", () -> new OpalingotItem());
	public static final RegistryObject<Item> OPALSLAYERAXE = REGISTRY.register("opalslayeraxe", () -> new OpalslayeraxeItem());
	public static final RegistryObject<Item> CHEESEMOONBLOCK = block(EmersonStockMastersModBlocks.CHEESEMOONBLOCK);
	public static final RegistryObject<Item> PEICEOCHEESE = REGISTRY.register("peiceocheese", () -> new PeiceocheeseItem());
	public static final RegistryObject<Item> PICKLE = REGISTRY.register("pickle", () -> new PickleItem());
	public static final RegistryObject<Item> EMERSONBOMB = block(EmersonStockMastersModBlocks.EMERSONBOMB);
	public static final RegistryObject<Item> PICKLEARMOR_HELMET = REGISTRY.register("picklearmor_helmet", () -> new PicklearmorItem.Helmet());
	public static final RegistryObject<Item> PICKLEARMOR_CHESTPLATE = REGISTRY.register("picklearmor_chestplate", () -> new PicklearmorItem.Chestplate());
	public static final RegistryObject<Item> PICKLEARMOR_LEGGINGS = REGISTRY.register("picklearmor_leggings", () -> new PicklearmorItem.Leggings());
	public static final RegistryObject<Item> PICKLEARMOR_BOOTS = REGISTRY.register("picklearmor_boots", () -> new PicklearmorItem.Boots());
	public static final RegistryObject<Item> CHEESESLIME_SPAWN_EGG = REGISTRY.register("cheeseslime_spawn_egg", () -> new ForgeSpawnEggItem(EmersonStockMastersModEntities.CHEESESLIME, -256, -6724096, new Item.Properties()));
	public static final RegistryObject<Item> CHEESEWORM_SPAWN_EGG = REGISTRY.register("cheeseworm_spawn_egg", () -> new ForgeSpawnEggItem(EmersonStockMastersModEntities.CHEESEWORM, -256, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> CHEESEPLANT = doubleBlock(EmersonStockMastersModBlocks.CHEESEPLANT);
	public static final RegistryObject<Item> RAWPICKLESHOES = REGISTRY.register("rawpickleshoes", () -> new RawpickleshoesItem());
	public static final RegistryObject<Item> CHEESEDIRT = block(EmersonStockMastersModBlocks.CHEESEDIRT);
	public static final RegistryObject<Item> CHEESEBUSH = block(EmersonStockMastersModBlocks.CHEESEBUSH);
	public static final RegistryObject<Item> CHUNKYCHEESE_SPAWN_EGG = REGISTRY.register("chunkycheese_spawn_egg", () -> new ForgeSpawnEggItem(EmersonStockMastersModEntities.CHUNKYCHEESE, -205, -10066330, new Item.Properties()));
	public static final RegistryObject<Item> SPAWNCHEESEBLOCK = block(EmersonStockMastersModBlocks.SPAWNCHEESEBLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	private static RegistryObject<Item> doubleBlock(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), new Item.Properties()));
	}
}
