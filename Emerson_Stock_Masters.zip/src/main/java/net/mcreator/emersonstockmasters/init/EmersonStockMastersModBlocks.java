
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.emersonstockmasters.block.SpawncheeseblockBlock;
import net.mcreator.emersonstockmasters.block.OpalblockBlock;
import net.mcreator.emersonstockmasters.block.EmersonbombBlock;
import net.mcreator.emersonstockmasters.block.CheeseplantBlock;
import net.mcreator.emersonstockmasters.block.CheesemoonblockBlock;
import net.mcreator.emersonstockmasters.block.CheesedirtBlock;
import net.mcreator.emersonstockmasters.block.CheesebushBlock;
import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

public class EmersonStockMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EmersonStockMastersMod.MODID);
	public static final RegistryObject<Block> OPALBLOCK = REGISTRY.register("opalblock", () -> new OpalblockBlock());
	public static final RegistryObject<Block> CHEESEMOONBLOCK = REGISTRY.register("cheesemoonblock", () -> new CheesemoonblockBlock());
	public static final RegistryObject<Block> EMERSONBOMB = REGISTRY.register("emersonbomb", () -> new EmersonbombBlock());
	public static final RegistryObject<Block> CHEESEPLANT = REGISTRY.register("cheeseplant", () -> new CheeseplantBlock());
	public static final RegistryObject<Block> CHEESEDIRT = REGISTRY.register("cheesedirt", () -> new CheesedirtBlock());
	public static final RegistryObject<Block> CHEESEBUSH = REGISTRY.register("cheesebush", () -> new CheesebushBlock());
	public static final RegistryObject<Block> SPAWNCHEESEBLOCK = REGISTRY.register("spawncheeseblock", () -> new SpawncheeseblockBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
