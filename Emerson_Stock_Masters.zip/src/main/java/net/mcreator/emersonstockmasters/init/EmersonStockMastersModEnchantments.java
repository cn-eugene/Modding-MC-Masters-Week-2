
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.emersonstockmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.emersonstockmasters.enchantment.LightingEnchantment;
import net.mcreator.emersonstockmasters.EmersonStockMastersMod;

public class EmersonStockMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, EmersonStockMastersMod.MODID);
	public static final RegistryObject<Enchantment> LIGHTING = REGISTRY.register("lighting", () -> new LightingEnchantment());
}
