
package net.mcreator.emersonstockmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.emersonstockmasters.entity.ChunkycheeseEntity;
import net.mcreator.emersonstockmasters.client.model.Modelchunkycheese;

public class ChunkycheeseRenderer extends MobRenderer<ChunkycheeseEntity, Modelchunkycheese<ChunkycheeseEntity>> {
	public ChunkycheeseRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelchunkycheese(context.bakeLayer(Modelchunkycheese.LAYER_LOCATION)), 1.2f);
	}

	@Override
	public ResourceLocation getTextureLocation(ChunkycheeseEntity entity) {
		return new ResourceLocation("emerson_stock_masters:textures/entities/texture_4.png");
	}
}
