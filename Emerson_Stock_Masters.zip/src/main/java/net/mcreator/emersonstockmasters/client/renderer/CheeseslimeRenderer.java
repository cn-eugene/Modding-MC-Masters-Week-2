
package net.mcreator.emersonstockmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SlimeModel;

import net.mcreator.emersonstockmasters.entity.CheeseslimeEntity;

public class CheeseslimeRenderer extends MobRenderer<CheeseslimeEntity, SlimeModel<CheeseslimeEntity>> {
	public CheeseslimeRenderer(EntityRendererProvider.Context context) {
		super(context, new SlimeModel(context.bakeLayer(ModelLayers.SLIME)), 0.6f);
	}

	@Override
	public ResourceLocation getTextureLocation(CheeseslimeEntity entity) {
		return new ResourceLocation("emerson_stock_masters:textures/entities/slime_1.png");
	}
}
