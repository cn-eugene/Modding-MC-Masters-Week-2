// Made with Blockbench 4.10.3
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelmoonworm<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "moonworm"), "main");
	private final ModelPart body;
	private final ModelPart foot;
	private final ModelPart foot2;
	private final ModelPart foot3;
	private final ModelPart foot4;
	private final ModelPart eyes;

	public Modelmoonworm(ModelPart root) {
		this.body = root.getChild("body");
		this.foot = root.getChild("foot");
		this.foot2 = root.getChild("foot2");
		this.foot3 = root.getChild("foot3");
		this.foot4 = root.getChild("foot4");
		this.eyes = root.getChild("eyes");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition body = partdefinition
				.addOrReplaceChild("body",
						CubeListBuilder.create().texOffs(23, 17).addBox(-2.0F, -3.0F, -8.0F, 3.0F, 3.0F, 16.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));

		PartDefinition foot = partdefinition.addOrReplaceChild("foot", CubeListBuilder.create().texOffs(0, 20).addBox(
				-4.0F, 0.0F, -12.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 22.0F, 8.0F));

		PartDefinition foot2 = partdefinition.addOrReplaceChild("foot2", CubeListBuilder.create().texOffs(10, 12)
				.addBox(-4.0F, 0.0F, -9.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 22.0F, 8.0F));

		PartDefinition foot3 = partdefinition.addOrReplaceChild("foot3", CubeListBuilder.create().texOffs(15, 6).addBox(
				-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(2.0F, 24.0F, 0.0F));

		PartDefinition foot4 = partdefinition.addOrReplaceChild("foot4", CubeListBuilder.create().texOffs(24, 4).addBox(
				-1.0F, -2.0F, -4.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(2.0F, 24.0F, 0.0F));

		PartDefinition eyes = partdefinition.addOrReplaceChild("eyes", CubeListBuilder.create(),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition cube_r1 = eyes.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(1, 6).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.0F, -2.0F, -8.0F, -3.1416F, 0.0F, 2.3562F));

		PartDefinition cube_r2 = eyes.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(1, 6).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0F, -2.0F, -8.0F, -3.1082F, 0.028F, 2.4439F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		foot.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		foot2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		foot3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		foot4.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		eyes.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		this.foot3.yRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
		this.foot2.yRot = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
		this.foot4.yRot = Mth.cos(limbSwing * 1.0F) * 1.0F * limbSwingAmount;
		this.foot.yRot = Mth.cos(limbSwing * 1.0F) * -1.0F * limbSwingAmount;
	}
}