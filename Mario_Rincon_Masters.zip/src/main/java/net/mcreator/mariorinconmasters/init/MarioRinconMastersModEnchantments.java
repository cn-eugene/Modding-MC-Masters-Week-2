
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mariorinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.mariorinconmasters.enchantment.OEnchantment;
import net.mcreator.mariorinconmasters.MarioRinconMastersMod;

public class MarioRinconMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MarioRinconMastersMod.MODID);
	public static final RegistryObject<Enchantment> O = REGISTRY.register("o", () -> new OEnchantment());
}
