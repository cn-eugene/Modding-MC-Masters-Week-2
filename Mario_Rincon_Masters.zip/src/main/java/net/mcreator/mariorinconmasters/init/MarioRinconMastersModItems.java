
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mariorinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mariorinconmasters.item.DItem;
import net.mcreator.mariorinconmasters.item.CryingoreItem;
import net.mcreator.mariorinconmasters.item.CringbattleaxeItem;
import net.mcreator.mariorinconmasters.MarioRinconMastersMod;

public class MarioRinconMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MarioRinconMastersMod.MODID);
	public static final RegistryObject<Item> CRYINGORE = REGISTRY.register("cryingore", () -> new CryingoreItem());
	public static final RegistryObject<Item> CRYINGOREBLOCK = block(MarioRinconMastersModBlocks.CRYINGOREBLOCK);
	public static final RegistryObject<Item> CRINGBATTLEAXE = REGISTRY.register("cringbattleaxe", () -> new CringbattleaxeItem());
	public static final RegistryObject<Item> NUKE = block(MarioRinconMastersModBlocks.NUKE);
	public static final RegistryObject<Item> D_HELMET = REGISTRY.register("d_helmet", () -> new DItem.Helmet());
	public static final RegistryObject<Item> D_CHESTPLATE = REGISTRY.register("d_chestplate", () -> new DItem.Chestplate());
	public static final RegistryObject<Item> D_LEGGINGS = REGISTRY.register("d_leggings", () -> new DItem.Leggings());
	public static final RegistryObject<Item> D_BOOTS = REGISTRY.register("d_boots", () -> new DItem.Boots());
	public static final RegistryObject<Item> TIMMY_SPAWN_EGG = REGISTRY.register("timmy_spawn_egg", () -> new ForgeSpawnEggItem(MarioRinconMastersModEntities.TIMMY, -16776961, -6684877, new Item.Properties()));
	public static final RegistryObject<Item> TIMMYPLANT = block(MarioRinconMastersModBlocks.TIMMYPLANT);
	public static final RegistryObject<Item> WATERWOOD = block(MarioRinconMastersModBlocks.WATERWOOD);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
