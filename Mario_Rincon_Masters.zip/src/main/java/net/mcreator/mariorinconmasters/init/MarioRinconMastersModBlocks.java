
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mariorinconmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.mariorinconmasters.block.WaterwoodBlock;
import net.mcreator.mariorinconmasters.block.TimmyplantBlock;
import net.mcreator.mariorinconmasters.block.NukeBlock;
import net.mcreator.mariorinconmasters.block.CryingoreblockBlock;
import net.mcreator.mariorinconmasters.MarioRinconMastersMod;

public class MarioRinconMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MarioRinconMastersMod.MODID);
	public static final RegistryObject<Block> CRYINGOREBLOCK = REGISTRY.register("cryingoreblock", () -> new CryingoreblockBlock());
	public static final RegistryObject<Block> NUKE = REGISTRY.register("nuke", () -> new NukeBlock());
	public static final RegistryObject<Block> TIMMYPLANT = REGISTRY.register("timmyplant", () -> new TimmyplantBlock());
	public static final RegistryObject<Block> WATERWOOD = REGISTRY.register("waterwood", () -> new WaterwoodBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
