
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mariorinconmasters.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.mariorinconmasters.MarioRinconMastersMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MarioRinconMastersModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MarioRinconMastersMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(MarioRinconMastersModBlocks.NUKE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MarioRinconMastersModItems.CRINGBATTLEAXE.get());
			tabData.accept(MarioRinconMastersModItems.D_HELMET.get());
			tabData.accept(MarioRinconMastersModItems.D_CHESTPLATE.get());
			tabData.accept(MarioRinconMastersModItems.D_LEGGINGS.get());
			tabData.accept(MarioRinconMastersModItems.D_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MarioRinconMastersModItems.TIMMY_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MarioRinconMastersModItems.CRYINGORE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MarioRinconMastersModBlocks.CRYINGOREBLOCK.get().asItem());
			tabData.accept(MarioRinconMastersModBlocks.TIMMYPLANT.get().asItem());
			tabData.accept(MarioRinconMastersModBlocks.WATERWOOD.get().asItem());
		}
	}
}
