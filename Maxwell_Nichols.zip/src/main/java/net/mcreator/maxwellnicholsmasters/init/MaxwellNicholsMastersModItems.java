
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxwellnicholsmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.maxwellnicholsmasters.item.TheupsidedownItem;
import net.mcreator.maxwellnicholsmasters.item.NothingItem;
import net.mcreator.maxwellnicholsmasters.item.BorderItem;
import net.mcreator.maxwellnicholsmasters.MaxwellNicholsMastersMod;

public class MaxwellNicholsMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MaxwellNicholsMastersMod.MODID);
	public static final RegistryObject<Item> FOLTYN = block(MaxwellNicholsMastersModBlocks.FOLTYN);
	public static final RegistryObject<Item> NOTHING = REGISTRY.register("nothing", () -> new NothingItem());
	public static final RegistryObject<Item> NUKEBLOCK = block(MaxwellNicholsMastersModBlocks.NUKEBLOCK);
	public static final RegistryObject<Item> BORDER_HELMET = REGISTRY.register("border_helmet", () -> new BorderItem.Helmet());
	public static final RegistryObject<Item> BORDER_CHESTPLATE = REGISTRY.register("border_chestplate", () -> new BorderItem.Chestplate());
	public static final RegistryObject<Item> BORDER_LEGGINGS = REGISTRY.register("border_leggings", () -> new BorderItem.Leggings());
	public static final RegistryObject<Item> BORDER_BOOTS = REGISTRY.register("border_boots", () -> new BorderItem.Boots());
	public static final RegistryObject<Item> BERGERMAGMACUBE_SPAWN_EGG = REGISTRY.register("bergermagmacube_spawn_egg", () -> new ForgeSpawnEggItem(MaxwellNicholsMastersModEntities.BERGERMAGMACUBE, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> THEUPSIDEDOWN = REGISTRY.register("theupsidedown", () -> new TheupsidedownItem());
	public static final RegistryObject<Item> CLICK = block(MaxwellNicholsMastersModBlocks.CLICK);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
