
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxwellnicholsmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.maxwellnicholsmasters.MaxwellNicholsMastersMod;

public class MaxwellNicholsMastersModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, MaxwellNicholsMastersMod.MODID);
	public static final RegistryObject<Potion> DEATH = REGISTRY.register("death", () -> new Potion(new MobEffectInstance(MaxwellNicholsMastersModMobEffects.URMOM.get(), 10000, 0, false, true)));
}
