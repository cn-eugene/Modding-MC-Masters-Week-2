
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxwellnicholsmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.maxwellnicholsmasters.block.TheupsidedownPortalBlock;
import net.mcreator.maxwellnicholsmasters.block.NukeblockBlock;
import net.mcreator.maxwellnicholsmasters.block.FoltynBlock;
import net.mcreator.maxwellnicholsmasters.block.ClickBlock;
import net.mcreator.maxwellnicholsmasters.MaxwellNicholsMastersMod;

public class MaxwellNicholsMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MaxwellNicholsMastersMod.MODID);
	public static final RegistryObject<Block> FOLTYN = REGISTRY.register("foltyn", () -> new FoltynBlock());
	public static final RegistryObject<Block> NUKEBLOCK = REGISTRY.register("nukeblock", () -> new NukeblockBlock());
	public static final RegistryObject<Block> THEUPSIDEDOWN_PORTAL = REGISTRY.register("theupsidedown_portal", () -> new TheupsidedownPortalBlock());
	public static final RegistryObject<Block> CLICK = REGISTRY.register("click", () -> new ClickBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
