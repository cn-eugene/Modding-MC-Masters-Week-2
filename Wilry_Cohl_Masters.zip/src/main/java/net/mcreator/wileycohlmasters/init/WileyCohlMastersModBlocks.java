
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wileycohlmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.wileycohlmasters.block.UpsidedownPortalBlock;
import net.mcreator.wileycohlmasters.block.StylishgrassBlock;
import net.mcreator.wileycohlmasters.block.StylishDirtBlock;
import net.mcreator.wileycohlmasters.block.PurpleleavesBlock;
import net.mcreator.wileycohlmasters.block.DeathoreBlock;
import net.mcreator.wileycohlmasters.block.DeathbombBlock;
import net.mcreator.wileycohlmasters.block.BluelogBlock;
import net.mcreator.wileycohlmasters.block.BlueflowerBlock;
import net.mcreator.wileycohlmasters.WileyCohlMastersMod;

public class WileyCohlMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, WileyCohlMastersMod.MODID);
	public static final RegistryObject<Block> DEATHORE = REGISTRY.register("deathore", () -> new DeathoreBlock());
	public static final RegistryObject<Block> DEATHBOMB = REGISTRY.register("deathbomb", () -> new DeathbombBlock());
	public static final RegistryObject<Block> UPSIDEDOWN_PORTAL = REGISTRY.register("upsidedown_portal", () -> new UpsidedownPortalBlock());
	public static final RegistryObject<Block> BLUEFLOWER = REGISTRY.register("blueflower", () -> new BlueflowerBlock());
	public static final RegistryObject<Block> BLUELOG = REGISTRY.register("bluelog", () -> new BluelogBlock());
	public static final RegistryObject<Block> PURPLELEAVES = REGISTRY.register("purpleleaves", () -> new PurpleleavesBlock());
	public static final RegistryObject<Block> STYLISHGRASS = REGISTRY.register("stylishgrass", () -> new StylishgrassBlock());
	public static final RegistryObject<Block> STYLISH_DIRT = REGISTRY.register("stylish_dirt", () -> new StylishDirtBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
