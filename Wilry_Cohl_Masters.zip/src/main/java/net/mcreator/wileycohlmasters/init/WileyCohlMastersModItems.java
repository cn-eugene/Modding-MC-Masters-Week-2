
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.wileycohlmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.wileycohlmasters.item.UpsidedownItem;
import net.mcreator.wileycohlmasters.item.SytheItem;
import net.mcreator.wileycohlmasters.item.RawDeathItem;
import net.mcreator.wileycohlmasters.item.GrimreaperarmorItem;
import net.mcreator.wileycohlmasters.item.DeathingotItem;
import net.mcreator.wileycohlmasters.item.DeathbladeItem;
import net.mcreator.wileycohlmasters.item.BladeofdestinyItem;
import net.mcreator.wileycohlmasters.WileyCohlMastersMod;

public class WileyCohlMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, WileyCohlMastersMod.MODID);
	public static final RegistryObject<Item> DEATHORE = block(WileyCohlMastersModBlocks.DEATHORE);
	public static final RegistryObject<Item> RAW_DEATH = REGISTRY.register("raw_death", () -> new RawDeathItem());
	public static final RegistryObject<Item> DEATHINGOT = REGISTRY.register("deathingot", () -> new DeathingotItem());
	public static final RegistryObject<Item> DEATHBLADE = REGISTRY.register("deathblade", () -> new DeathbladeItem());
	public static final RegistryObject<Item> DEATHBOMB = block(WileyCohlMastersModBlocks.DEATHBOMB);
	public static final RegistryObject<Item> GRIMREAPERARMOR_HELMET = REGISTRY.register("grimreaperarmor_helmet", () -> new GrimreaperarmorItem.Helmet());
	public static final RegistryObject<Item> GRIMREAPERARMOR_CHESTPLATE = REGISTRY.register("grimreaperarmor_chestplate", () -> new GrimreaperarmorItem.Chestplate());
	public static final RegistryObject<Item> GRIMREAPERARMOR_LEGGINGS = REGISTRY.register("grimreaperarmor_leggings", () -> new GrimreaperarmorItem.Leggings());
	public static final RegistryObject<Item> GRIMREAPERARMOR_BOOTS = REGISTRY.register("grimreaperarmor_boots", () -> new GrimreaperarmorItem.Boots());
	public static final RegistryObject<Item> UPSIDEDOWN = REGISTRY.register("upsidedown", () -> new UpsidedownItem());
	public static final RegistryObject<Item> DEMIGORGON_SPAWN_EGG = REGISTRY.register("demigorgon_spawn_egg", () -> new ForgeSpawnEggItem(WileyCohlMastersModEntities.DEMIGORGON, -16777216, -6750208, new Item.Properties()));
	public static final RegistryObject<Item> SYTHE = REGISTRY.register("sythe", () -> new SytheItem());
	public static final RegistryObject<Item> BLUEFLOWER = block(WileyCohlMastersModBlocks.BLUEFLOWER);
	public static final RegistryObject<Item> BLUELOG = block(WileyCohlMastersModBlocks.BLUELOG);
	public static final RegistryObject<Item> PURPLELEAVES = block(WileyCohlMastersModBlocks.PURPLELEAVES);
	public static final RegistryObject<Item> STYLISHGRASS = block(WileyCohlMastersModBlocks.STYLISHGRASS);
	public static final RegistryObject<Item> STYLISH_DIRT = block(WileyCohlMastersModBlocks.STYLISH_DIRT);
	public static final RegistryObject<Item> BLADEOFDESTINY = REGISTRY.register("bladeofdestiny", () -> new BladeofdestinyItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
