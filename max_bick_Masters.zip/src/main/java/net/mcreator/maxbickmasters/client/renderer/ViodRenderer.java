
package net.mcreator.maxbickmasters.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.GhastModel;

import net.mcreator.maxbickmasters.entity.ViodEntity;

public class ViodRenderer extends MobRenderer<ViodEntity, GhastModel<ViodEntity>> {
	public ViodRenderer(EntityRendererProvider.Context context) {
		super(context, new GhastModel(context.bakeLayer(ModelLayers.GHAST)), 7.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ViodEntity entity) {
		return new ResourceLocation("max_bick_masters:textures/entities/armadillo.png");
	}
}
