
package net.mcreator.maxbickmasters.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class FuseitItem extends Item {
	public FuseitItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
