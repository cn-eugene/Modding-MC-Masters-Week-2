
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxbickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.maxbickmasters.block.YummywoodBlock;
import net.mcreator.maxbickmasters.block.YummygrassBlock;
import net.mcreator.maxbickmasters.block.PopBlock;
import net.mcreator.maxbickmasters.block.FuseitblockBlock;
import net.mcreator.maxbickmasters.MaxBickMastersMod;

public class MaxBickMastersModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MaxBickMastersMod.MODID);
	public static final RegistryObject<Block> FUSEITBLOCK = REGISTRY.register("fuseitblock", () -> new FuseitblockBlock());
	public static final RegistryObject<Block> POP = REGISTRY.register("pop", () -> new PopBlock());
	public static final RegistryObject<Block> YUMMYWOOD = REGISTRY.register("yummywood", () -> new YummywoodBlock());
	public static final RegistryObject<Block> YUMMYGRASS = REGISTRY.register("yummygrass", () -> new YummygrassBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
