
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxbickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.maxbickmasters.item.IyeItem;
import net.mcreator.maxbickmasters.item.FuseitswordItem;
import net.mcreator.maxbickmasters.item.FuseitingotItem;
import net.mcreator.maxbickmasters.item.FuseitItem;
import net.mcreator.maxbickmasters.item.CatItem;
import net.mcreator.maxbickmasters.MaxBickMastersMod;

public class MaxBickMastersModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MaxBickMastersMod.MODID);
	public static final RegistryObject<Item> FUSEIT = REGISTRY.register("fuseit", () -> new FuseitItem());
	public static final RegistryObject<Item> FUSEITBLOCK = block(MaxBickMastersModBlocks.FUSEITBLOCK);
	public static final RegistryObject<Item> FUSEITINGOT = REGISTRY.register("fuseitingot", () -> new FuseitingotItem());
	public static final RegistryObject<Item> FUSEITSWORD = REGISTRY.register("fuseitsword", () -> new FuseitswordItem());
	public static final RegistryObject<Item> CAT = REGISTRY.register("cat", () -> new CatItem());
	public static final RegistryObject<Item> POP = block(MaxBickMastersModBlocks.POP);
	public static final RegistryObject<Item> IYE_HELMET = REGISTRY.register("iye_helmet", () -> new IyeItem.Helmet());
	public static final RegistryObject<Item> IYE_CHESTPLATE = REGISTRY.register("iye_chestplate", () -> new IyeItem.Chestplate());
	public static final RegistryObject<Item> IYE_LEGGINGS = REGISTRY.register("iye_leggings", () -> new IyeItem.Leggings());
	public static final RegistryObject<Item> IYE_BOOTS = REGISTRY.register("iye_boots", () -> new IyeItem.Boots());
	public static final RegistryObject<Item> VIOD_SPAWN_EGG = REGISTRY.register("viod_spawn_egg", () -> new ForgeSpawnEggItem(MaxBickMastersModEntities.VIOD, -3407668, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> YUMMYWOOD = block(MaxBickMastersModBlocks.YUMMYWOOD);
	public static final RegistryObject<Item> YUMMYGRASS = block(MaxBickMastersModBlocks.YUMMYGRASS);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
