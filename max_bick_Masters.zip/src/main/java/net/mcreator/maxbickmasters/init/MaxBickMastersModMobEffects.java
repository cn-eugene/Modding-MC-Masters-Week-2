
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxbickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.maxbickmasters.potion.MagmaMobEffect;
import net.mcreator.maxbickmasters.MaxBickMastersMod;

public class MaxBickMastersModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MaxBickMastersMod.MODID);
	public static final RegistryObject<MobEffect> MAGMA = REGISTRY.register("magma", () -> new MagmaMobEffect());
}
