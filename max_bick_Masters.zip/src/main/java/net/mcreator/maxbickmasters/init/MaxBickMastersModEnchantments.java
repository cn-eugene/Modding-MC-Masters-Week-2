
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.maxbickmasters.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.maxbickmasters.enchantment.IweEnchantment;
import net.mcreator.maxbickmasters.MaxBickMastersMod;

public class MaxBickMastersModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, MaxBickMastersMod.MODID);
	public static final RegistryObject<Enchantment> IWE = REGISTRY.register("iwe", () -> new IweEnchantment());
}
